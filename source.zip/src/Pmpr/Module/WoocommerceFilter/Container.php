<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673b8c4db181b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\WoocommerceFilter\Traits\CommonTrait; abstract class Container extends BaseClass { use CommonTrait; }
