<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4b8846b1e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\WoocommerceFilter\Traits\CommonTrait; abstract class Container extends BaseClass { use CommonTrait; }
