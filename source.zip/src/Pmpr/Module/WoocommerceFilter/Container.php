<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517a26c5de             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\WoocommerceFilter\Traits\CommonTrait; abstract class Container extends BaseClass { use CommonTrait; }
