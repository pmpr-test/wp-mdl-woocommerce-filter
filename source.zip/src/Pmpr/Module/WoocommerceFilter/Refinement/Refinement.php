<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4707a28b9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Refinement; use Pmpr\Module\WoocommerceFilter\Container; class Refinement extends Container { protected array $elements = []; public function yoyomkiwwiaywwoq(Element $kqywgoqsmuswammk) : self { $this->elements[] = $kqywgoqsmuswammk; return $this; } public function gscgsuogmcswyaai() : array { return $this->elements; } public function aqyikqugcomoqqqi() { $this->yoyomkiwwiaywwoq(Price::symcgieuakksimmu())->yoyomkiwwiaywwoq(Rating::symcgieuakksimmu())->yoyomkiwwiaywwoq(OnSale::symcgieuakksimmu())->yoyomkiwwiaywwoq(InStock::symcgieuakksimmu())->yoyomkiwwiaywwoq(Featured::symcgieuakksimmu())->yoyomkiwwiaywwoq(Attribute::symcgieuakksimmu()); } }
