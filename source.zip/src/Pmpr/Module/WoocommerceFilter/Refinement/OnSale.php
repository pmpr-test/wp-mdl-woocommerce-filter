<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc0b8b2b87             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Refinement; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use WP_Query; class OnSale extends Element { const isasoemkymwoiqem = "\157\x6e\137\x73\141\x6c\145"; public function __construct() { $this->name = self::isasoemkymwoiqem; $this->type = Constants::semqugiuwygamias; $this->icon = IconInterface::uaimoioocayauuca; $this->title = __("\x4f\x6e\x20\123\141\154\x65", PR__MDL__WOOCOMMERCE_FILTER); parent::__construct(); } public function msgqcwqsemkmwqss($oyiyuuoguwwaksaa, &$gqgemcmoicmgaqie) { $ccouywuicsaqmais = (bool) $this->kokwyquiqyoaaioc()->oiqmuywqkkmuswuc($this->aakmagwggmkoiiyu(), false); if ($ccouywuicsaqmais) { $eqgoocgaqwqcimie = array_merge([0], $this->uwkmaywceaaaigwo()->aqasygcsqysmmyke()->gucosgmwouaweasy()); if ($gqgemcmoicmgaqie instanceof WP_Query) { $gqgemcmoicmgaqie->set(Constants::eqomgewoayseioos, $eqgoocgaqwqcimie); } else { if (is_array($gqgemcmoicmgaqie)) { $gqgemcmoicmgaqie[Constants::eqomgewoayseioos] = $eqgoocgaqwqcimie; } } } return parent::msgqcwqsemkmwqss($oyiyuuoguwwaksaa, $gqgemcmoicmgaqie); } }
