<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae9605d7a6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Traits; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\WoocommerceFilter\Helper; use Pmpr\Module\WoocommerceFilter\Setting; use Pmpr\Module\WoocommerceFilter\WoocommerceFilter; use WP_Taxonomy; trait CommonTrait { public function kokwyquiqyoaaioc() : Helper { return Helper::symcgieuakksimmu(); } public function qeomwskywaguqyyu() : bool { return Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::ykqqgqskiygugscu, false); } public function mqmocoguqcyymgqu() : ?array { return $this->caokeucsksukesyo()->aqasygcsqysmmyke()->mqmocoguqcyymgqu(); } public function wwqoiqcoccacyyyc() : bool { return $this->ocksiywmkyaqseou(WoocommerceFilter::geiygweugseyomyy . "\141\x6c\154\x6f\167\x5f\x61\144\x64", $this->caokeucsksukesyo()->aqasygcsqysmmyke()->omuogooguicuqewu()); } }
