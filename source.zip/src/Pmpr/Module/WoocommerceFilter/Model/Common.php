<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ece1a51a2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Model; use Pmpr\Common\Foundation\ORM\DB\Model; abstract class Common extends Model { public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->myysgyqcumekoueo()->okgmqaeuaeymaocm($this->akuociswqmoigkas()); parent::ckgmycmaukqgkosk(); } }
