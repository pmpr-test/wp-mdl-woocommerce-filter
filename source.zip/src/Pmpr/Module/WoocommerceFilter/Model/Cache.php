<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67e934c82c89a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\ORM\Model; class Cache extends Model { public function register() { $this->guiaswksukmgageq(__('Cache', PR__MDL__WOOCOMMERCE_FILTER))->muuwuqssqkaieqge(__('Caches', PR__MDL__WOOCOMMERCE_FILTER)); } public function uwmqacgewuauagai() { $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->gysoeyaguiyewoes(Constants::ciyoccqkiamemcmm)->gswweykyogmsyawy(__('Value', PR__MDL__WOOCOMMERCE_FILTER))); parent::uwmqacgewuauagai(); } }
