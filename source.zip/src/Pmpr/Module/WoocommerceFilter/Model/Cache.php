<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b70f0b5bc             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\ORM\Model; class Cache extends Model { public function register() { $this->guiaswksukmgageq(__("\103\x61\x63\150\145", PR__MDL__WOOCOMMERCE_FILTER))->muuwuqssqkaieqge(__("\x43\141\x63\150\x65\163", PR__MDL__WOOCOMMERCE_FILTER)); } public function uwmqacgewuauagai() { $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->gysoeyaguiyewoes(Constants::ciyoccqkiamemcmm)->gswweykyogmsyawy(__("\126\x61\x6c\165\145", PR__MDL__WOOCOMMERCE_FILTER))); parent::uwmqacgewuauagai(); } }
