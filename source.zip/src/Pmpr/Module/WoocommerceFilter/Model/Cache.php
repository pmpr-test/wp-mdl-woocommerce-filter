<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc0b8b2b87             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\ORM\Model; class Cache extends Model { public function register() { $this->guiaswksukmgageq(__("\103\141\x63\150\x65", PR__MDL__WOOCOMMERCE_FILTER))->muuwuqssqkaieqge(__("\103\141\143\x68\x65\x73", PR__MDL__WOOCOMMERCE_FILTER)); } public function uwmqacgewuauagai() { $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->gysoeyaguiyewoes(Constants::ciyoccqkiamemcmm)->gswweykyogmsyawy(__("\x56\141\154\165\x65", PR__MDL__WOOCOMMERCE_FILTER))); parent::uwmqacgewuauagai(); } }
