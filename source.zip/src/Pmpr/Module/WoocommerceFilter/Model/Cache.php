<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705dd05bf55             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\ORM\Model; class Cache extends Model { public function register() { $this->guiaswksukmgageq(__("\x43\x61\x63\150\145", PR__MDL__WOOCOMMERCE_FILTER))->muuwuqssqkaieqge(__("\103\141\143\150\145\163", PR__MDL__WOOCOMMERCE_FILTER)); } public function uwmqacgewuauagai() { $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->gysoeyaguiyewoes(Constants::ciyoccqkiamemcmm)->gswweykyogmsyawy(__("\126\141\x6c\x75\x65", PR__MDL__WOOCOMMERCE_FILTER))); parent::uwmqacgewuauagai(); } }
