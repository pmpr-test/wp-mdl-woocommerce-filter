<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ece1a51a2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Cache extends Common { public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->myysgyqcumekoueo()->yioesawwewqaigow(IconInterface::yiaicmmssocumqco)->guiaswksukmgageq(__("\x43\141\143\150\x65", PR__MDL__WOOCOMMERCE_FILTER))->muuwuqssqkaieqge(__("\103\x61\x63\x68\x65\x73", PR__MDL__WOOCOMMERCE_FILTER)); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(Constants::ciyoccqkiamemcmm)->acokiqqgsmoqaeyu()->gswweykyogmsyawy(__("\x56\141\x6c\x75\145", PR__MDL__WOOCOMMERCE_FILTER))); parent::ewaqwooqoqmcoomi(); } }
