<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517a26c5de             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Cache extends Common { public function register() { $this->guiaswksukmgageq(__("\103\141\143\150\145", PR__MDL__WOOCOMMERCE_FILTER))->muuwuqssqkaieqge(__("\103\141\143\x68\x65\x73", PR__MDL__WOOCOMMERCE_FILTER)); } public function uwmqacgewuauagai() { $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->gysoeyaguiyewoes(Constants::ciyoccqkiamemcmm)->gswweykyogmsyawy(__("\x56\141\154\x75\145", PR__MDL__WOOCOMMERCE_FILTER))); parent::uwmqacgewuauagai(); } }
