<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7d895647             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Model; use Pmpr\Module\WoocommerceFilter\Container; class Model extends Container { public function mameiwsayuyquoeq() { Cache::symcgieuakksimmu(); } }
