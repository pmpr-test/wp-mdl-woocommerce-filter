<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672f20c6042b3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Frontend; class Sidebar extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\x6f\x6f\143\x6f\155\155\x65\162\x63\x65\137\x73\151\144\145\142\x61\162", [$this, "\x72\x65\156\x64\145\162"], 50); } public function render() { if ($this->wwqoiqcoccacyyyc() && $this->caokeucsksukesyo()->aqasygcsqysmmyke()->omuogooguicuqewu()) { $this->skqqcuwuuumqkykk(); } } }
