<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4b8846b1e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Frontend; class Sidebar extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x77\x6f\x6f\x63\157\x6d\x6d\145\162\143\145\x5f\x73\151\x64\x65\142\x61\162", [$this, "\x72\x65\x6e\x64\145\x72"], 50); } public function render() { if ($this->wwqoiqcoccacyyyc() && $this->caokeucsksukesyo()->aqasygcsqysmmyke()->omuogooguicuqewu()) { $this->skqqcuwuuumqkykk(); } } }
