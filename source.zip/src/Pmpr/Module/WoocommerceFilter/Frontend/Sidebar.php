<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc5d87a549             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Frontend; class Sidebar extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\157\x6f\143\x6f\x6d\155\145\162\x63\145\x5f\163\x69\x64\x65\x62\x61\162", [$this, "\x72\x65\156\144\x65\x72"], 50); } public function render() { if ($this->wwqoiqcoccacyyyc() && $this->caokeucsksukesyo()->aqasygcsqysmmyke()->omuogooguicuqewu()) { $this->skqqcuwuuumqkykk(); } } }
