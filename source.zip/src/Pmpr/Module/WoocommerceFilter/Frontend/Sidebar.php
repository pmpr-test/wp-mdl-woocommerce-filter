<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd8ed60d7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Frontend; class Sidebar extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x77\x6f\x6f\x63\157\155\x6d\x65\162\143\x65\x5f\x73\x69\x64\145\x62\141\x72", [$this, "\x72\x65\x6e\144\x65\x72"], 50); } public function render() { if ($this->wwqoiqcoccacyyyc() && $this->caokeucsksukesyo()->aqasygcsqysmmyke()->omuogooguicuqewu()) { $this->skqqcuwuuumqkykk(); } } }
