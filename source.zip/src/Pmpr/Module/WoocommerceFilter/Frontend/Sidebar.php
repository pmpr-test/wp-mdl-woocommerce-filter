<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517a26c5de             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Frontend; class Sidebar extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\157\157\x63\157\x6d\x6d\x65\162\143\145\x5f\x73\151\x64\145\142\141\x72", [$this, "\162\145\x6e\144\x65\x72"], 50); } public function render() { if (!($this->wwqoiqcoccacyyyc() && $this->caokeucsksukesyo()->aqasygcsqysmmyke()->omuogooguicuqewu())) { goto ukkcmocamwgiqayu; } $this->skqqcuwuuumqkykk(); ukkcmocamwgiqayu: } }
