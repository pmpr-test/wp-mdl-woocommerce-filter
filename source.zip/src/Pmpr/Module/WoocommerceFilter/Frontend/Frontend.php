<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7d895647             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Frontend; class Frontend extends Common { public function mameiwsayuyquoeq() { Sidebar::symcgieuakksimmu(); } }
