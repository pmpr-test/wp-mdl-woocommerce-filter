<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc0b8b2b87             |
    |_______________________________________|
*/
 namespace Pmpr\Module\WoocommerceFilter\Frontend; class Frontend extends Common { public function mameiwsayuyquoeq() { Sidebar::symcgieuakksimmu(); } }
